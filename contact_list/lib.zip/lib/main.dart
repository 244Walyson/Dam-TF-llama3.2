import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lista de Contatos',
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: ContactsScreen(),
    );
  }
}

class ContactsScreen extends StatefulWidget {
  @override
  _ContactsScreenState createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  final _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lista de Contatos'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_sweep),
            onPressed: _clearAllContacts,
            tooltip: 'Limpar todos os contatos',
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _firestore.collection('contacts').orderBy('createdAt').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final contacts = snapshot.data!.docs;

          if (contacts.isEmpty) {
            return const Center(
              child: Text(
                'Nenhum contato encontrado!',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: contacts.length,
            separatorBuilder: (context, index) => const Divider(),
            itemBuilder: (context, index) {
              final contact = contacts[index];
              return Card(
                elevation: 3,
                child: ListTile(
                  leading: CircleAvatar(
                    radius: 25,
                    backgroundImage: contact['avatarUrl'] != null && contact['avatarUrl'].isNotEmpty
                        ? NetworkImage(contact['avatarUrl'])
                        : null,
                    child: contact['avatarUrl'] == null || contact['avatarUrl'].isEmpty
                        ? const Icon(Icons.person, size: 30)
                        : null,
                  ),
                  title: Text(
                    contact['name'],
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('📞 ${contact['phone']}'),
                      Text('✉️ ${contact['email']}'),
                    ],
                  ),
                  trailing: Wrap(
                    spacing: 8,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _editContactDialog(contact),
                        tooltip: 'Editar contato',
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteContact(contact.id),
                        tooltip: 'Excluir contato',
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addContactDialog,
        label: const Text('Adicionar'),
        icon: const Icon(Icons.add),
      ),
    );
  }

  void _addContactDialog() {
    final _nameController = TextEditingController();
    final _phoneController = TextEditingController();
    final _emailController = TextEditingController();
    final _cpfController = TextEditingController();
    final _avatarUrlController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Adicionar Contato'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTextField(_nameController, 'Nome'),
              _buildTextField(_phoneController, 'Telefone', TextInputType.phone),
              _buildTextField(_emailController, 'Email'),
              _buildTextField(_cpfController, 'CPF', TextInputType.number),
              _buildTextField(_avatarUrlController, 'URL do Avatar'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              _addContact(
                _nameController.text,
                _phoneController.text,
                _emailController.text,
                _cpfController.text,
                _avatarUrlController.text,
              );
              Navigator.pop(context);
            },
            child: const Text('Adicionar'),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String labelText, [TextInputType keyboardType = TextInputType.text]) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: labelText,
          border: OutlineInputBorder(),
        ),
        keyboardType: keyboardType,
      ),
    );
  }

  void _addContact(String name, String phone, String email, String cpf, String avatarUrl) {
    if (name.isNotEmpty && phone.isNotEmpty && email.isNotEmpty && cpf.isNotEmpty) {
      _firestore.collection('contacts').add({
        'name': name,
        'phone': phone,
        'email': email,
        'cpf': cpf,
        'avatarUrl': avatarUrl,
        'createdAt': FieldValue.serverTimestamp(),
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Contato adicionado com sucesso!')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Por favor, preencha todos os campos!')));
    }
  }

  void _editContactDialog(QueryDocumentSnapshot contact) {
    final _nameController = TextEditingController(text: contact['name']);
    final _phoneController = TextEditingController(text: contact['phone']);
    final _emailController = TextEditingController(text: contact['email']);
    final _cpfController = TextEditingController(text: contact['cpf']);
    final _avatarUrlController = TextEditingController(text: contact['avatarUrl']);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Editar Contato'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTextField(_nameController, 'Nome'),
              _buildTextField(_phoneController, 'Telefone', TextInputType.phone),
              _buildTextField(_emailController, 'Email'),
              _buildTextField(_cpfController, 'CPF', TextInputType.number),
              _buildTextField(_avatarUrlController, 'URL do Avatar'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              _editContact(
                contact.id,
                _nameController.text,
                _phoneController.text,
                _emailController.text,
                _cpfController.text,
                _avatarUrlController.text,
              );
              Navigator.pop(context);
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
  }

  void _editContact(String id, String name, String phone, String email, String cpf, String avatarUrl) {
    if (name.isNotEmpty && phone.isNotEmpty && email.isNotEmpty && cpf.isNotEmpty) {
      _firestore.collection('contacts').doc(id).update({
        'name': name,
        'phone': phone,
        'email': email,
        'cpf': cpf,
        'avatarUrl': avatarUrl,
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Contato atualizado com sucesso!')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Por favor, preencha todos os campos!')));
    }
  }

  void _deleteContact(String id) {
    _firestore.collection('contacts').doc(id).delete();
  }

  void _clearAllContacts() {
    _firestore.collection('contacts').get().then((snapshot) {
      for (var doc in snapshot.docs) {
        doc.reference.delete();
      }
    });
  }
}
